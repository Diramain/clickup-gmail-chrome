/**
 * Page World Script for InboxSDK
 * This runs in the page context (not extension context)
 */

// InboxSDK requires this file to be web accessible
console.log('[ClickUp Gmail Chrome] Page world loaded');
